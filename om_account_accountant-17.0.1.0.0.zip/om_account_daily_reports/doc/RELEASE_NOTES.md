## Module <om_account_daily_reports>

#### 25.11.2023
#### Version 17.0.1.0.0
##### ADD
- initial release
