## Module <hrms_dashboard>

#### 28.11.2023
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Open HRMS dashboard

#### 08.12.2023
#### Version 17.0.1.0.1
##### UPDT
- Bug Fix-Resolved the rendering error in the dashboard.
