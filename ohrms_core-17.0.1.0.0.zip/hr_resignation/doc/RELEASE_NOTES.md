## Module <hr_resignation>

#### 28.11.2023
#### Version 17.0.1.0.0
##### ADD

- Initial commit for OpenHRMS Resignation
